import requests
import json
from flask import Flask, jsonify, request, render_template
import mysql.connector
import math
from datetime import datetime
import pytz
from mysql.connector import errorcode

tz = pytz.timezone("Asia/Ho_Chi_Minh")

def tuple_2_list(tups):
    for i in range(len(tups)):
        tups[i] = list(tups[i])
        tups[i] = tups[i][0]
    return tups

def log_error(log_script):
    now = datetime.now(tz)
    current_time = now.strftime("%Y/%m/%d %H:%M:%S")

class beetoon_api:
    def __init__(self,host='localhost',user='root',password="", db='crawl_beetoon',pool_size=5):
        self.config = {
            'user': user,
            'password': password,
            'host': host,
            'database': db,
            'raise_on_warnings': True,
            'pool_size': 5
        }
        self.mydatabase = mysql.connector.connect(
            host=host,
            user=user,
            password=password,
            database=db,
            raise_on_warnings=True,
            pool_size=pool_size
        )
        self.mycursor = self.mydatabase.cursor()
        self.insert_query = None
        self.select_query = None
        self.update_query = None
        self.logged_in_user = list()

    def db_close(self):
        self.mycursor.close()
        self.mydatabase.close()

    def db_connection(self):
        while True:
            try:
                # Attempt to connect to the database
                self.mydatabase = mysql.connector.connect(**self.config)
                self.mycursor = self.mydatabase.cursor()
                
                return self.mydatabase, self.mycursor
            except mysql.connector.Error as err:
                continue

    def get_from_manga(self,per_page, page, table_name='manga'):
        try:
            alldata = dict()
            alldata_manga=list()
            self.mydatabase, self.mycursor = self.db_connection()
            self.select_query = f"""SELECT `id`,`manga_id`,`manga_name`,`authors`,`categories`,`slug`,`status`,`is_active`,`image`,`chapter_count`,`rank`,`view`,`description`,`release_at`,`created_at`,`updated_at` FROM `{table_name}`"""
            self.mycursor.execute(self.select_query)
            tmp = self.mycursor.fetchall()[::-1]
            
            for manga in tmp:
                data = dict()
                meta_data = dict()

                # QUERY DATA FOR EACH MANGA
                for i in range(len(manga)):
                    author_list = manga[3].split(",")
                    authors=[]
                    for author in author_list:
                        authors_dict = dict()
                        author_id = self.get_1_value_by_column(col_find='name', val=author, col_get='author_id', table_name='authors')
                        authors_dict['id'] = author_id
                        authors_dict['name'] = author
                        authors.append(authors_dict)

                    data['authors']=authors
                    data['id']=manga[0]
                    data['type']='manga'
                    data['title']=manga[1]
                    data['categories'] = manga[4]
                    data['slug']=manga[5].replace("--","-")
                    data['status']=manga[6]
                    data['is_active']=manga[7]
                    data['image']=manga[8]
                    data['chapter_count']=manga[9]
                    data['rate']=manga[10]
                    data['view']=manga[11]
                    data['description']=manga[12]
                    data['release_at']=manga[13]
                    data['created_at']=manga[14]
                    data['updated_at']=manga[15]
                alldata_manga.append(data)
            pagination_data = dict()
            pagination_data['total'] = len(alldata_manga)
            pagination_data['page_size'] = per_page
            pagination_data['current'] = page
            pagination_data['total_pages'] = len(alldata_manga)//per_page + 1

            # GET 'pagination' data
            meta_data["pagination"] = pagination_data

            # alldata['code'] = 200
            # alldata['message'] = 'Success'
            alldata['data'] = alldata_manga
            alldata['pagination'] = meta_data
            
            # log debugger
            log_error("Success")
            
            self.db_close()
            return alldata
        except Exception as err:
            
            # log debugger
            log_error(f"{err}")
            # If a database error occurs, print the error message and attempt to reconnect
            self.mydatabase, self.mycursor = self.db_connection()
            self.mycursor.close()
            self.mydatabase.close()
            return jsonify({"Message": f"Error: {err}, refresh to reconnect"})
    

    def get_manga_by_id(self, manga_id, table_name='manga'):
        try:
            alldata = dict()
            alldata_manga=list()
            self.mydatabase, self.mycursor = self.db_connection()
            self.select_query = f"""SELECT `id`,`manga_id`,`manga_name`,`authors`,`categories`,`slug`,`status`,`is_active`,`image`,`chapter_count`,`rank`,`view`,`description`,`release_at`,`created_at`,`updated_at` FROM `{table_name}` WHERE `manga_id`='{manga_id}'"""
            self.mycursor.execute(self.select_query)
            tmp = self.mycursor.fetchall()

            for manga in tmp:
                data = dict()
                meta_data = dict()

                # QUERY DATA FOR EACH MANGA
                for i in range(len(manga)):
                    author_list = manga[3].split(",")
                    authors=[]
                    cate_list = manga[4].split(", ")
                    categories=[]

                    # data["authors"]
                    for author in author_list:
                        authors_dict = dict()
                        author_id = self.get_1_value_by_column(col_find='name', val=author, col_get='author_id', table_name='authors')
                        authors_dict['id'] = author_id
                        authors_dict['name'] = author
                        authors.append(authors_dict)

                    # data["categories"]
                    for category in cate_list:
                        cate_dict = dict()
                        cate_id = self.get_1_value_by_column(col_find='title', val=category, col_get='category_id', table_name='categories')
                        cate_dict['id'] = cate_id
                        cate_dict['title'] = category
                        cate_dict['is_active'] = True
                        cate_dict['description'] = None
                        categories.append(cate_dict)
                    
                    # data["chapters"]
                    chapters= list()
                    chapter_id = self.get_all_value_by_column(column="chapter_id",col_find="manga_id",val=manga[0],table_name="chapters")
                    chapter_name = self.get_all_value_by_column(column="chapter_name",col_find="manga_id",val=manga[0],table_name="chapters")
                    chapter_thumbnail_count = self.get_all_value_by_column(column="thumbnail_count",col_find="manga_id",val=manga[0],table_name="chapters")
                    chapter_created_at = self.get_all_value_by_column(column="created_at",col_find="manga_id",val=manga[0],table_name="chapters")
                    chapter_updated_at = self.get_all_value_by_column(column="updated_at",col_find="manga_id",val=manga[0],table_name="chapters")
                    for i in range(len(chapter_id)):
                        chapter_dict = dict()
                        chapter_dict['id'] = chapter_id[i]
                        chapter_dict['manga_id'] = manga[0]
                        chapter_dict['name'] = chapter_name[i]
                        chapter_dict['is_active'] = True
                        chapter_dict['thumbnail_count'] = chapter_thumbnail_count[i]
                        chapter_dict['created_at'] = chapter_created_at[i]
                        chapter_dict['updated_at'] = chapter_updated_at[i]
                        chapters.append(chapter_dict)
            
                    data['chapters'] = chapters
                    data['authors']=authors
                    data['categories']=categories
                    data['id']=manga[0]
                    data['type']='manga'
                    data['title']=manga[1]
                    data['slug']=manga[5].replace("--","-")
                    data['status']=manga[6]
                    data['is_active']=manga[7]
                    data['image']=manga[8]
                    data['chapter_count']=manga[9]
                    data['rate']=manga[10]
                    data['viewer']=manga[11]
                    data['description']=manga[12]
                    data['release_at']=manga[13]
                    data['created_at']=manga[14]
                    data['updated_at']=manga[15]
                alldata_manga.append(data)
            alldata['code']= 200
            alldata['message'] = "Success"
            alldata['data'] = alldata_manga
            log_error("Success")

            self.db_close()
            return alldata
        except Exception as err:
            # If a database error occurs, print the error message and attempt to reconnect
            
            log_error(f"{err}")
            self.db_close()
            self.mydatabase, self.mycursor = self.db_connection()
            return jsonify({"Message": f"Error: {err}, refresh to reconnect"})

    def get_chapter_list_by_manga(self, manga_id, table_name="chapters"):
        try:
            alldata = dict()
            chapter_data =list()
            self.mydatabase, self.mycursor = self.db_connection()
            chapter_id = self.get_all_value_by_column(column="chapter_id", col_find="manga_id",val=manga_id,table_name=table_name)
            chapter_name = self.get_all_value_by_column(column="chapter_name", col_find="manga_id",val=manga_id,table_name=table_name)
            thumbnail_count = self.get_all_value_by_column(column="thumbnail_count", col_find="manga_id",val=manga_id,table_name=table_name)
            created_at = self.get_all_value_by_column(column="created_at", col_find="manga_id",val=manga_id,table_name=table_name)
            updated_at = self.get_all_value_by_column(column="updated_at", col_find="manga_id",val=manga_id,table_name=table_name)
            for i in range(len(chapter_id)):
                chapter_dict = dict()
                chapter_dict['id'] = chapter_id[i]
                chapter_dict['manga_id'] = manga_id
                chapter_dict['name'] = chapter_name[i]
                chapter_dict['is_active'] = 1
                chapter_dict['thumbnail_count'] = thumbnail_count[i]
                chapter_dict['created_at'] = created_at[i]
                chapter_dict['updated_at'] = updated_at[i]
                chapter_data.append(chapter_dict)
            meta_data = dict()
            pagination_data = dict()
            page_size =  50
            pagination_data['total'] = len(chapter_id)
            pagination_data['page_size']= page_size
            pagination_data['current']=1
            pagination_data['total_pages']=len(chapter_id)//page_size + 1
            
            meta_data['pagination'] = pagination_data

            alldata['code'] = 200
            alldata['message'] = "Success"
            alldata['data'] = chapter_data
            alldata['meta'] = meta_data
            log_error("Success")
            return alldata
        except Exception as err:
            # If a database error occurs, print the error message and attempt to reconnect            
            log_error(f"{err}")
            self.db_close()
            self.mydatabase, self.mycursor = self.db_connection()
            return jsonify({"Message": f"Error: {err}, refresh to reconnect"})
    
    def get_chapter_by_id(self, manga_id, chapter_id):
        try:
            self.mydatabase, self.mycursor = self.db_connection()
            alldata = dict()
            chapter_data = dict()
            sql_id = self.get_1_value_by_2_column(column="id", col_find_1="manga_id",val_1=manga_id, col_find_2="chapter_id", val_2=chapter_id,table_name='chapters')
            sql_thumbnail_count = self.get_1_value_by_2_column(column="thumbnail_count", col_find_1="manga_id",val_1=manga_id, col_find_2="chapter_id", val_2=chapter_id,table_name='chapters')
            sql_chapter_name = self.get_1_value_by_2_column(column="chapter_name", col_find_1="manga_id",val_1=manga_id, col_find_2="chapter_id", val_2=chapter_id,table_name='chapters')
            sql_created_at = self.get_1_value_by_2_column(column="created_at", col_find_1="manga_id",val_1=manga_id, col_find_2="chapter_id", val_2=chapter_id,table_name='chapters')
            sql_updated_at = self.get_1_value_by_2_column(column="updated_at", col_find_1="manga_id",val_1=manga_id, col_find_2="chapter_id", val_2=chapter_id,table_name='chapters')

            chapter_data['sql_id'] = sql_id
            chapter_data['chapter_id'] = chapter_id
            chapter_data['chapter_name'] = sql_chapter_name
            chapter_data['is_active'] = True
            chapter_data['thumbnail_count'] = sql_thumbnail_count
            chapter_data['created_at'] = sql_created_at
            chapter_data['updated_at'] = sql_updated_at
            chapter_data['viewer'] = 1

            thumbnails_data = list()
            thumbnails_url = self.get_all_value_by_2_column(col_find_1="manga_id",val_1=manga_id, col_find_2="chapter_id", val_2=chapter_id,table_name='chapter_thumbnails')
            for i in thumbnails_url:
                thumbnails_dict = dict()
                thumbnails_dict['id'] = i[0]
                thumbnails_dict['chapter_id'] = chapter_id
                thumbnails_dict['thumbnail_url'] = i[1]
                thumbnails_dict['is_active'] = True
                thumbnails_dict['created_at'] = i[2]
                thumbnails_dict['updated_at'] = i[3]
                thumbnails_data.append(thumbnails_dict)
            chapter_data['thumbnails'] = thumbnails_data
            alldata['code'] = 200
            alldata['message'] = "Success"
            alldata['data'] = chapter_data
            log_error("Success")
            return alldata
        except Exception as err:

            log_error(f"{err}")
            # If a database error occurs, print the error message and attempt to reconnect
            self.mydatabase, self.mycursor = self.db_connection()
            self.mycursor.close()
            self.mydatabase.close()
            return jsonify({"Message": f"Error: {err}, refresh to reconnect"})

    def get_categories(self,per_page, page, table_name="categories"):
        try:
            alldata = dict()
            categories_data = list()
            self.mydatabase, self.mycursor = self.db_connection()
            sql_id = self.get_all_value_in_column(column='id', table_name=table_name)
            title = self.get_all_value_in_column(column='title', table_name=table_name)
            category_id = self.get_all_value_in_column(column='category_id', table_name=table_name)
            slug = self.get_all_value_in_column(column='slug', table_name=table_name)
            total_manga = self.get_all_value_in_column(column='total_manga', table_name=table_name)
            description = self.get_all_value_in_column(column='description', table_name=table_name)
            created_at = self.get_all_value_in_column(column='created_at', table_name=table_name)
            updated_at = self.get_all_value_in_column(column='updated_at', table_name=table_name)
            
            for i in range(len(sql_id)):
                categories_dict = dict()
                categories_dict['id'] = sql_id[i]
                categories_dict['title'] = title[i]
                categories_dict['slug'] = slug[i]
                categories_dict['is_active'] = True
                categories_dict['total_manga'] = len(total_manga[i].split(","))
                categories_dict['image'] = None
                categories_dict['description'] = description[i]
                categories_dict['created_at'] = created_at[i]
                categories_dict['updated_at'] = updated_at[i]
                categories_data.append(categories_dict)
            pagination_data = dict()
            meta_data = dict()
            page_size = per_page
            pagination_data['total'] = len(sql_id)
            pagination_data['page_size']= page_size
            pagination_data['current']=page
            pagination_data['total_pages']=len(sql_id)//page_size + 1
            
            meta_data['pagination'] = pagination_data
            
            alldata['data'] = categories_data
            alldata['meta'] = meta_data
            log_error("Success")
            return alldata
        except Exception as err:
            # If a database error occurs, print the error message and attempt to reconnect
            log_error(f"{err}")
            
            self.mydatabase, self.mycursor = self.db_connection()
            self.mycursor.close()
            self.mydatabase.close()
            return jsonify({"Message": f"Error: {err}, refresh to reconnect"})
    
    def get_category_by_id(self,per_page, page, category_id, table_name='categories'):
        try:
            alldata = dict()
            self.mydatabase, self.mycursor = self.db_connection()
            total_manga_id_by_categories = self.get_1_value_by_column(col_find='category_id', val=category_id, col_get='total_manga', table_name=table_name).split(",")
            total_manga_id_by_categories = [int(i) for i in total_manga_id_by_categories]
            alldata_manga = list()
            meta_data = dict()
            for manga_id in total_manga_id_by_categories:
                manga_data = dict()
                data_in_row = self.get_all_row_by_column(col_find='manga_id', val=manga_id, table_name='manga')
                sql_id = manga_id
                
                author_list = self.get_1_value_by_column(col_find='manga_id', val=manga_id, col_get='authors', table_name='manga').split(",")
                authors=[]
                for author in author_list:
                    authors_dict = dict()
                    author_id = self.get_1_value_by_column(col_find='name', val=author, col_get='author_id', table_name='authors')
                    authors_dict['id'] = author_id
                    authors_dict['name'] = author
                    authors.append(authors_dict)

                cate_list = self.get_1_value_by_column(col_find='manga_id', val=manga_id, col_get='categories', table_name='manga').split(", ")
                categories=[]
                for category in cate_list:
                        cate_dict = dict()
                        cate_id = self.get_1_value_by_column(col_find='title', val=category, col_get='category_id', table_name='categories')
                        cate_dict['id'] = cate_id
                        cate_dict['title'] = category
                        cate_dict['is_active'] = True
                        cate_dict['description'] = None
                        categories.append(cate_dict)
                
                title = self.get_1_value_by_column(col_find='manga_id', val=manga_id, col_get='manga_name', table_name='manga')
                slug = self.get_1_value_by_column(col_find='manga_id', val=manga_id, col_get='slug', table_name='manga')
                image = self.get_1_value_by_column(col_find='manga_id', val=manga_id, col_get='image', table_name='manga')
                chapter_count = self.get_1_value_by_column(col_find='manga_id', val=manga_id, col_get='chapter_count', table_name='manga')
                rank = self.get_1_value_by_column(col_find='manga_id', val=manga_id, col_get='rank', table_name='manga')
                description = self.get_1_value_by_column(col_find='manga_id', val=manga_id, col_get='description', table_name='manga')
                release_at = self.get_1_value_by_column(col_find='manga_id', val=manga_id, col_get='release_at', table_name='manga')
                created_at = self.get_1_value_by_column(col_find='manga_id', val=manga_id, col_get='created_at', table_name='manga')
                updated_at = self.get_1_value_by_column(col_find='manga_id', val=manga_id, col_get='updated_at', table_name='manga')
                manga_data['id'] = manga_id
                manga_data['type'] = 'manga'
                manga_data['title'] = title
                manga_data['slug'] = slug
                manga_data['image'] = image
                manga_data['chapter_count'] = chapter_count
                manga_data['rank'] = rank
                manga_data['description'] = description
                manga_data['release_at'] = release_at
                manga_data['created_at'] = created_at
                manga_data['updated_at'] = updated_at
                manga_data['authors'] = authors
                manga_data['categories'] = categories
                alldata_manga.append(manga_data)

            pagination_data = dict()
            page_size = per_page
            pagination_data['total'] = len(alldata_manga)
            pagination_data['page_size'] = per_page
            pagination_data['current'] = page
            pagination_data['total_pages'] = len(alldata_manga)//per_page + 1

            meta_data['pagination'] = pagination_data

            alldata['code'] = 200
            alldata['message'] = "Success"
            alldata['data'] = alldata_manga
            alldata['meta'] = meta_data
            log_error("Success")
            return alldata
        except Exception as err:
            log_error(f"{err}")
            # If a database error occurs, print the error message and attempt to reconnect
            self.mydatabase, self.mycursor = self.db_connection()
            self.mycursor.close()
            self.mydatabase.close()
            return jsonify({"Message": f"Error: {err}, refresh to reconnect"})

    def insert_user_inf(self, username,email, password, table_name="user_information"):
        try:
            self.mydatabase, self.mycursor = self.db_connection()
            now = datetime.now(tz)
            current_time = now.strftime("%Y/%m/%d %H:%M:%S")
            log_error("Success")
            if username == "":
                return f"Please enter your username"
            elif email == "":
                return f"Please enter your email"
            elif password == "":
                return f"Please enter your password"

            user_check = f"""SELECT COUNT(*) FROM `{table_name}` WHERE `username`='{username}'"""
            email_check = f"""SELECT COUNT(*) FROM `{table_name}` WHERE `email`='{email}'"""
            
            self.mycursor.execute(user_check)
            user_count = self.mycursor.fetchone()[0]
            self.mycursor.execute(email_check)
            email_count = self.mycursor.fetchone()[0]

            if user_count>0:
                return f"Username already existed, try again!"
            elif email_count>0:
                return f"Email already existed, try again!"
            else:
                self.insert_query = f"""INSERT INTO `{table_name}`(`username`,`email`, `password`,`created_at`,`updated_at`) VALUES ("{username}","{email}","{password}","{current_time}","{current_time}")"""
                self.mycursor.execute(self.insert_query)
                self.mydatabase.commit()
                return f"""User : `{username}` registered successfully !"""
            

        except Exception as err:
            log_error(f"{err}")
            # If a database error occurs, print the error message and attempt to reconnect
            self.mydatabase, self.mycursor = self.db_connection()
            self.mycursor.close()
            self.mydatabase.close()
            return jsonify({"Message": f"Error: {err}, refresh to reconnect"})

    def check_user_login(self, username,email, password, table_name="user_information"):
        try:
            self.mydatabase, self.mycursor = self.db_connection()
            if username != "":
                user_inf = self.get_all_row_by_column(col_find="username", val=username, table_name=table_name)
            elif email != "":
                user_inf = self.get_all_row_by_column(col_find="email", val=email, table_name=table_name)
            for user in user_inf:
                sql_username, sql_email, sql_password = user[1], user[2], user[3]
                if username == sql_username and password == sql_password or email == sql_email and password == sql_password:
                    self.update_1_value_by_column(col_find="username", val_find=username, col_update="is_active", val_update=1, table_name="user_information")
                    return f"Login successfully !"
                    break
            log_error("Success")
            return f"Wrong username or password. Try again !"

        except Exception as err:
            # If a database error occurs, print the error message and attempt to reconnect
            
            
            log_error(f"{err}")
            self.mydatabase, self.mycursor = self.db_connection()
            self.mycursor.close()
            self.mydatabase.close()
            return jsonify({"Message": f"Error: {err}, refresh to reconnect"})

    def verify_email(self, email, table_name="user_information"):
        try:
            self.mydatabase, self.mycursor = self.db_connection()
            now = datetime.now(tz)
            current_time = now.strftime("%Y/%m/%d %H:%M:%S") 
            user_inf = []

            if email != "":
                user_inf = self.get_all_row_by_column(col_find="email", val=email, table_name=table_name)
            for user in user_inf:
                sql_email = user[2]
                if sql_email == email:
                    self.update_1_value_by_column(col_find="email", val_find=email, col_update="verified_at", val_update=current_time, table_name="user_information")
                    return f"""Confirm email sent to '{email}'"""
                    break
            log_error("Success")

            return f"Something went wrong."
        except Exception as err:
            # If a database error occurs, print the error message and attempt to reconnect
            
            
            log_error(f"{err}")
            self.mydatabase, self.mycursor = self.db_connection()
            self.mycursor.close()
            self.mydatabase.close()
            return jsonify({"Message": f"Error: {err}, refresh to reconnect"})

    def post_comment_manga(self,user_id, manga_id,comment, table_name="comments"):
        try:
            self.mydatabase, self.mycursor = self.db_connection()
            now = datetime.now(tz)
            current_time = now.strftime("%Y/%m/%d %H:%M:%S")
            comment_id_max = 0
            comment_id = max(self.get_all_value_by_column(column="comment_id",col_find="manga_id",val=manga_id,table_name="comments"))
            comment_id = max(comment_id, comment_id_max) + 1
            log_error("Success")

            try:
                user_state = self.get_1_value_by_column(col_find='id', val=user_id, col_get='is_active', table_name="user_information")
            except:
                return f"This user doesn't exist!"
            if user_state == 0:
                return f"Please log in to comment!"
            else:
                insert_comment = f"""INSERT INTO `{table_name}`(`user_id`, `comment_id`,`manga_id`,`content`,`created_at`,`updated_at`) VALUES ("{user_id}","{comment_id}","{manga_id}","{comment}","{current_time}","{current_time}")"""
                self.mycursor.execute(insert_comment)
                self.mydatabase.commit()
                return f"Add comment successfully"
        except Exception as err:
            # If a database error occurs, print the error message and attempt to reconnect
            log_error(f"{err}")
            self.mydatabase, self.mycursor = self.db_connection()
            self.mycursor.close()
            self.mydatabase.close()
            return jsonify({"Message": f"Error: {err}, refresh to reconnect"})

    def user_logout(self, username):
        try:
            self.mydatabase, self.mycursor = self.db_connection()
            now = datetime.now(tz)
            current_time = now.strftime("%Y/%m/%d %H:%M:%S")
            log_error("Success")
            try:
                user_state = self.get_1_value_by_column(col_find="username", val=username, col_get='is_active', table_name='user_information')
            except Exception:
                return f"Please log in first!"
            if user_state == 1:
                self.update_1_value_by_column(col_find="username", val_find=username, col_update="is_active", val_update=0, table_name="user_information")
                self.update_1_value_by_column(col_find="username", val_find=username, col_update="last_login", val_update=current_time, table_name="user_information")
                return f"Logged out successfully!"
            else:
                return f"Please log in first!"
        except Exception as err:
            # If a database error occurs, print the error message and attempt to reconnect
            log_error(f"{err}")
            
            self.mydatabase, self.mycursor = self.db_connection()
            self.mycursor.close()
            self.mydatabase.close()
            return jsonify({"Message": f"Error: {err}, refresh to reconnect"})

    def get_comment_manga(self, manga_id):
        try:
            alldata = dict()
            data_list = list()
            self.mydatabase, self.mycursor = self.db_connection()
            total_comments = self.get_all_row_by_column(col_find="manga_id", val=manga_id, table_name="comments")
            for comment in total_comments:
                data_dict = dict()
                user_inf = dict()
                _, sql_comment_id, sql_user_id, sql_manga_id, sql_parent_id, sql_content, sql_created_at, sql_updated_at = comment
                
                user_data = self.get_all_row_by_column(col_find="id", val=sql_user_id, table_name="user_information")[0]
                sql_username = user_data[1]
                sql_user_email = user_data[2]
                sql_phone_number = user_data[4]
                sql_avatar = user_data[5]
                sql_provider = user_data[6]
                sql_is_active = user_data[7]
                sql_created_at = user_data[8]
                sql_last_login = user_data[11]

                user_inf['id']=sql_user_id
                user_inf['name']=sql_username
                user_inf['email']=sql_user_email
                user_inf['phone_number']=sql_phone_number
                user_inf['avatar']=sql_avatar
                user_inf['provider']=sql_provider
                user_inf['is_active']=sql_is_active
                user_inf['last_login']=sql_last_login
                
                data_dict['id'] = sql_comment_id
                data_dict['user_id'] = sql_user_id
                data_dict['manga_id'] = sql_manga_id
                data_dict['parent_id'] = sql_parent_id
                data_dict['content'] = sql_content
                data_dict['is_active'] = True
                data_dict['created_at'] = sql_created_at
                data_dict['updated_at'] = sql_updated_at
                data_dict['user'] = user_inf
                data_list.append(data_dict)
            alldata['data'] = data_list
            log_error("Success")
            return alldata
        except Exception as err:
            # If a database error occurs, print the error message and attempt to reconnect
            
            
            log_error(f"{err}")

            self.mydatabase, self.mycursor = self.db_connection()
            self.mycursor.close()
            self.mydatabase.close()
            return jsonify({"Message": f"Error: {err}, refresh to reconnect"})
    
    def update_comment_manga(self, manga_id, comment_id, content):
        try:
            self.mydatabase, self.mycursor = self.db_connection()
            self.update_1_value_by_2_column(col_find_1="manga_id",val_find_1=manga_id,col_find_2="comment_id",val_find_2=comment_id, col_update="content", val_update=content, table_name="comments")
            log_error("Success")
            return f"Updated comment successfully!"
        except Exception as err:
            # If a database error occurs, print the error message and attempt to reconnect
            log_error(f"{err}")

            self.mydatabase, self.mycursor = self.db_connection()
            self.mycursor.close()
            self.mydatabase.close()
            return jsonify({"Message": f"Error: {err}, refresh to reconnect"})

    def delete_comment_manga(self, manga_id, comment_id):
        try:
            self.mydatabase, self.mycursor = self.db_connection()
            self.delete_by_1_column(col_find_1="manga_id",val_find_1=manga_id,col_find_2="comment_id",val_find_2=comment_id, table_name="comments")
            log_error("Success")
            return f"Deleted comment successfully!"
        except Exception as err:
            # If a database error occurs, print the error message and attempt to reconnect
            log_error(f"{err}")
            self.mydatabase, self.mycursor = self.db_connection()
            self.mycursor.close()
            self.mydatabase.close()
            return jsonify({"Message": f"Error: {err}, refresh to reconnect"})

    def show_user_information(self, username):
        try:
            self.mydatabase, self.mycursor = self.db_connection()
            alldata = dict()
            try:
                user_data = self.get_all_row_by_column(col_find="username", val=username, table_name="user_information")[0]
            except Exception:
                return {"Message":"No information. Please Enter username profile"}
            if self.mycursor.rowcount>0:
                alldata['id']=user_data[0]
                alldata['name']=user_data[1]
                alldata['email']=user_data[2]
                alldata['avatar']=user_data[5]
                alldata['phone_number']=user_data[4]
                alldata['provider']=user_data[6]
                alldata['provider_id']=None
                alldata['email_verified_at']=user_data[12]
                alldata['is_active']=user_data[7]
                alldata['last_login']=user_data[11]
                alldata['activated_at']=user_data[12]
                alldata['created_at']=user_data[8]
                alldata['updated_at']=user_data[9]
                alldata['deleted_at']=user_data[10]
                log_error("Success")
                return alldata
        except Exception as err:
            # If a database error occurs, print the error message and attempt to reconnect
            log_error(f"{err}")

            self.mydatabase, self.mycursor = self.db_connection()
            self.mycursor.close()
            self.mydatabase.close()
            return jsonify({"Message": f"Error: {err}, refresh to reconnect"})

    def update_user_information(self,username, data_to_update, val_to_update):
        try:
            self.mydatabase, self.mycursor = self.db_connection()
            now = datetime.now(tz)
            current_time = now.strftime("%Y/%m/%d %H:%M:%S")

            self.update_1_value_by_column(col_find="username", val_find=username, col_update=data_to_update, val_update=val_to_update, table_name="user_information")
            self.update_1_value_by_column(col_find="username", val_find=username, col_update="updated_at", val_update=current_time, table_name="user_information")
            log_error("Success")
            return f"Updated profile successfully!"
        except Exception as err:
            # If a database error occurs, print the error message and attempt to reconnect
            log_error(f"{err}")

            self.mydatabase, self.mycursor = self.db_connection()
            self.mycursor.close()
            self.mydatabase.close()
            return jsonify({"Message": f"Error: {err}, refresh to reconnect"})

    def change_password(self, username, old_password, new_password):
        try:
            self.mydatabase, self.mycursor = self.db_connection()
            log_error("Success")
            try:
                user_data = self.get_all_row_by_column(col_find="username", val=username, table_name="user_information")[0]
            except Exception:
                return {"Message":"This username doesn't exist!"}
            user_password = user_data[3]
            if user_password != old_password:
                return {"Message":"Your old password is wrong"}
            else:
                if old_password == new_password:
                    return {"Message":"Your new password must be different"}
                else:
                    self.update_1_value_by_column(col_find="username", val_find=username, col_update="password", val_update=new_password, table_name="user_information")
                    return {"Message":"Your password changed successfully!"}
        except Exception as err:
            # If a database error occurs, print the error message and attempt to reconnect
            log_error(f"{err}")

            self.mydatabase, self.mycursor = self.db_connection()
            self.mycursor.close()
            self.mydatabase.close()
            return jsonify({"Message": f"Error: {err}, refresh to reconnect"})

    def add_favortite_manga(self, username, is_favorite, manga_id):
        try:
            self.mydatabase, self.mycursor = self.db_connection()
            now = datetime.now(tz)
            current_time = now.strftime("%Y/%m/%d %H:%M:%S")
            user_state = self.get_1_value_by_column(col_find="username", val=username, col_get='is_active', table_name='user_information')
            manga_id_list = self.get_all_value_in_column(column="manga_id", table_name="manga")
            log_error("Success")

            if user_state == 0:
                return f"Please log in to add your favorite manga"
            elif user_state == 1:
                try:
                    self.select_query = f"""SELECT `favorite_manga` FROM `user_information` WHERE `username`='{username}'"""
                    self.mycursor.execute(self.select_query)
                    user_favorite_manga = tuple_2_list(self.mycursor.fetchall())
                except TypeError:
                    user_favorite_manga = []
                favorite_manga = ""
                
                if manga_id not in manga_id_list:
                    return f"This manga is not existed!"
                else:
                    if user_favorite_manga[0] == None:
                        favorite_manga = str(manga_id)
                    else:
                        if str(manga_id) in user_favorite_manga[0].split(","):
                            return f"This manga have already on your favorite"
                        else:
                            favorite_manga = user_favorite_manga[0]
                            favorite_manga += ',' + str(manga_id)

                    self.update_1_value_by_column(col_find="username", val_find=username, col_update="favorite_manga", val_update=favorite_manga, table_name="user_information")
                    self.update_1_value_by_column(col_find="username", val_find=username, col_update="updated_at", val_update=current_time, table_name="user_information")
                    return f"This manga has added to your favorite"
        except Exception as err:
            # If a database error occurs, print the error message and attempt to reconnect
            log_error(f"{err}")

            self.mydatabase, self.mycursor = self.db_connection()
            self.mycursor.close()
            self.mydatabase.close()
            return jsonify({"Message": f"Error: {err}, refresh to reconnect"})
    
    def remove_favorite_manga(self, username, is_favorite, manga_id):
        try:
            self.mydatabase, self.mycursor = self.db_connection()
            now = datetime.now(tz)
            current_time = now.strftime("%Y/%m/%d %H:%M:%S")
            user_state = self.get_1_value_by_column(col_find="username", val=username, col_get='is_active', table_name='user_information')
            log_error("Success")
            if user_state == 0:
                return f"Please log in to remove your favorite manga"
            elif user_state == 1:
                try:
                    self.select_query = f"""SELECT `favorite_manga` FROM `user_information` WHERE `username`='{username}'"""
                    self.mycursor.execute(self.select_query)
                    user_favorite_manga = tuple_2_list(self.mycursor.fetchall())
                except TypeError:
                    user_favorite_manga = ""
                
                if user_favorite_manga[0] == None:
                    return f"You don't have any manga favorite"
                else:
                    user_favorite_manga[0] = user_favorite_manga[0].split(",")
                    manga_id = str(manga_id)
                    if manga_id not in user_favorite_manga[0]:
                        return f'''You haven't add this manga to your favorite'''
                    else:
                        user_favorite_manga[0].pop(user_favorite_manga[0].index(manga_id))
                        favorite_manga = ",".join(user_favorite_manga[0])
                        self.update_1_value_by_column(col_find="username", val_find=username, col_update="favorite_manga", val_update=favorite_manga, table_name="user_information")
                        self.update_1_value_by_column(col_find="username", val_find=username, col_update="updated_at", val_update=current_time, table_name="user_information")
                        return f"This manga has removed from your favorite"
        except Exception as err:
            # If a database error occurs, print the error message and attempt to reconnect
            log_error(f"{err}")
            self.mydatabase, self.mycursor = self.db_connection()
            self.mycursor.close()
            self.mydatabase.close()
            return jsonify({"Message": f"Error: {err}, refresh to reconnect"})

    def get_favorite_manga(self, username):
        try:
            self.mydatabase, self.mycursor = self.db_connection()
            try:
                self.select_query = f"""SELECT `favorite_manga` FROM `user_information` WHERE `username`='{username}'"""
                self.mycursor.execute(self.select_query)
                user_favorite_manga = tuple_2_list(self.mycursor.fetchall())
            except TypeError:
                user_favorite_manga = ""

            user_state = self.get_1_value_by_column(col_find="username", val=username, col_get='is_active', table_name='user_information')
            
            user_id = None
            alldata = dict()
            data_manga_list = list()
            
            if user_state == 0:
                user_id = self.get_1_value_by_column(col_find="username", val=username, col_get="id", table_name="user_information")
                return f"Please log in to see your favorite"
            else:
                if user_favorite_manga[0] == None:
                    return f"No favorite manga"
                else:
                    user_favorite_manga[0] = user_favorite_manga[0].split(",")
                    for manga_id in user_favorite_manga[0]:
                        if manga_id != "":
                            data_manga_dict = dict()
                            manga_dict = dict()
                        
                            manga_id = int(manga_id)
                            data_manga = self.get_all_row_by_column(col_find="manga_id", val=manga_id, table_name="manga")[0]
                            # return data_manga
                            manga_dict['id']=data_manga[0]
                            manga_dict['title']=data_manga[4]
                            manga_dict['description']=data_manga[14]
                            manga_dict['status']=data_manga[8]
                            manga_dict['is_active']=data_manga[9]
                            manga_dict['chapter_count']=data_manga[11]
                            manga_dict['rank']=data_manga[12]
                            manga_dict['release_at']=data_manga[15]
                        
                            data_manga_dict['id'] = data_manga[0]
                            data_manga_dict['manga_id'] = data_manga[2]
                            data_manga_dict['user_id'] = user_id
                            data_manga_dict['counter'] = data_manga[11]
                            data_manga_dict['created_at'] = data_manga[16]
                            data_manga_dict['updated_at'] = data_manga[17]
                            data_manga_dict['manga'] = manga_dict

                            data_manga_list.append(data_manga_dict)
            alldata["data"] = data_manga_list            
            log_error("Success")
            return alldata
        except Exception as err:
            # If a database error occurs, print the error message and attempt to reconnect
            log_error(f"{err}")
            self.mydatabase, self.mycursor = self.db_connection()
            self.mycursor.close()
            self.mydatabase.close()
            return jsonify({"Message": f"Error: {err}, refresh to reconnect"})

    def update_1_value_by_column(self, col_find, val_find, col_update, val_update,table_name):
        self.update_query = f"""UPDATE `{table_name}` SET `{col_update}`='{val_update}' WHERE `{col_find}` = '{val_find}'"""
        self.mycursor.execute(self.update_query)
        self.mydatabase.commit()

    def update_1_value_by_2_column(self, col_find_1, val_find_1, col_find_2, val_find_2, col_update, val_update,table_name):
        self.update_query = f"""UPDATE `{table_name}` SET `{col_update}`='{val_update}' WHERE `{col_find_1}` = '{val_find_1}' AND `{col_find_2}` = '{val_find_2}'"""
        self.mycursor.execute(self.update_query)
        self.mydatabase.commit()

    def delete_by_1_column(self, col_find_1, val_find_1, col_find_2, val_find_2, table_name):
        self.update_query = f"""DELETE FROM `{table_name}` WHERE `{col_find_1}` = '{val_find_1}' AND `{col_find_2}` = '{val_find_2}'"""
        self.mycursor.execute(self.update_query)
        self.mydatabase.commit()
    
    def get_1_value_by_column(self, col_find, val, col_get, table_name):
        self.select_query = f"""SELECT `{col_get}` FROM `{table_name}` WHERE `{col_find}`='{val}'"""
        self.mycursor.execute(self.select_query)
        tmp = self.mycursor.fetchall()
        return tuple_2_list(tmp)[0]

    def get_1_value_by_2_column(self, column, col_find_1, val_1, col_find_2, val_2, table_name):
        self.select_query = f"""SELECT `{column}` FROM `{table_name}` WHERE `{col_find_1}`='{val_1}' AND `{col_find_2}`='{val_2}'"""
        self.mycursor.execute(self.select_query)
        tmp = self.mycursor.fetchall()
        return tuple_2_list(tmp)[0]

    def get_all_value_by_column(self,column, col_find, val, table_name):
        self.select_query = f"SELECT `{column}` FROM `{table_name}` WHERE `{col_find}`='{val}'"
        self.mycursor.execute(self.select_query)
        tmp = self.mycursor.fetchall()
        return tuple_2_list(tmp)
    
    def get_all_row_by_column(self,col_find, val, table_name):
        self.select_query = f"SELECT * FROM `{table_name}` WHERE `{col_find}`='{val}'"
        self.mycursor.execute(self.select_query)
        tmp = self.mycursor.fetchall()
        return tmp

    def get_all_value_in_column(self, column, table_name):
        self.select_query = f"SELECT `{column}` FROM `{table_name}`"
        self.mycursor.execute(self.select_query)
        tmp = self.mycursor.fetchall()
        return tuple_2_list(tmp)

    def get_all_value_by_2_column(self, col_find_1, val_1, col_find_2, val_2, table_name):
        self.select_query = f"SELECT `id`,`thumbnail_url`,`created_at`,`updated_at` FROM `{table_name}` WHERE `{col_find_1}`='{val_1}' AND `{col_find_2}`='{val_2}'"
        self.mycursor.execute(self.select_query)
        tmp = self.mycursor.fetchall()
        return tmp