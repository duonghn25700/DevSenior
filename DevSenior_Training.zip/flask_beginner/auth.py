from flask import Blueprint

auth = Blueprint("auth", __name__)

