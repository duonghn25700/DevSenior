from bs4 import BeautifulSoup
import requests

url = "https://ww6.beetoon.net/silver-demon-king/"
r = requests.get(url)
soup = BeautifulSoup(r.content, 'html.parser')
n_of_views = soup.find('div', class_ = 'view-times').text.replace("\n", "").replace(",","").split(" ")[1]
n_of_views = int(n_of_views)
print(n_of_views)