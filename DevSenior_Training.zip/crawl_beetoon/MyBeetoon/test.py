import mysql.connector
from beetoon.beetoon2sql_v4 import beetoon_insert
from datetime import datetime
host='localhost'
user='root'
password="" 
db='crawl_beetoon'
mydb = beetoon_insert(
            host=host,
            user=user,
            password=password,
            db=db
        )
username = ""
email = "duonghoangnguyen7@gmail.com"
password = "123456"
user_state = mydb.get_1_value_by_column(col_find='id', val=1, col_get='is_active', table_name="user_information")
print(type(user_state))