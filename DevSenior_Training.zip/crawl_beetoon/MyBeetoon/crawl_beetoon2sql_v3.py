from bs4 import BeautifulSoup
from urllib.parse import urlparse
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry
import json
import mysql.connector
from datetime import datetime
from beetoon.beetoon2sql_v2 import beetoon_insert
import re

session = requests.Session()
retry = Retry(total=5, backoff_factor=0.1, status_forcelist=[ 500, 502, 503, 504 ])
adapter = HTTPAdapter(max_retries=retry)
session.mount('http://', adapter)
session.mount('https://', adapter)

mydb = beetoon_insert(host='localhost',user='root',password="", db='crawl_beetoon')
beetoon_crawl = list()

def remove_non_letters(input_string):
    return re.sub(r'[^a-zA-Z\s]+', '', input_string)

def list_2_int(list1):
    list1 = [str(integer) for integer in list1]
    return int("".join(list1))
'''
genre : Chủ đề
start : Trang bắt đầu crawl
end   : Trang kết thúc crawl
'''
def crawl_beetoon_data(genre, start, end):
    cnt = start
    base = 'https://ww5.beetoon.net/'
    display_url = 'ww6.beetoon.net'
    base_url = 'https://ww6.beetoon.net/'
    url = base + genre
    manga_id = 0
    author_id = []
    cate_list = []
    author_list = []
    cnt_author_id = 1
    now = datetime.now()
    current_time = 1

    # MySQL : INSERT TABLE 'domain_crawlers'
    mydb.insert_2_domain_crawlers(domain_name=base,
    display_name=display_url, description=base_url, 
    created_at=current_time, updated_at=current_time)
    mydb.data_commit()

    # print(mydb.insert_query)

    # XỬ LÝ TỪNG TRANG TRONG MỤC ĐÃ CHỌN (LASTEST-UPDATE)
    while (cnt <= end):
        # LẤY SOURCE CODE CỦA TRANG
        pageUrl = url + '/page-' + str(cnt)
        r = session.get(pageUrl)
        soup = BeautifulSoup(r.content, 'html.parser')
        print("PageUrl: ", pageUrl)
        # TẤT CẢ CÁC BỘ MANGA TRONG PAGE
        comics = soup.find('div', class_="comics-grid")
        '''
        # DUYỆT CÁC BỘ TRUYỆN TRONG URL : https://ww6.beetoon.net/latest-update/
        #
        # CRAWL DATA TỪNG Chapter TRUYỆN --> 
        # manga_id = int, manga_name = str , thumbnail = jpg, author = str,
        # categories = list, last-update = str, chapters = dict
        # 
        '''
        for link in comics.findAll('div', class_="entry"):
            
            last_update = "Update soon"
            chapter_list = []
            chapterid = 1
            chapters = list()
            chapters = list()
            data_crawl = dict()
            manga_id = manga_id + 1
            manga_name = "update soon"
            author = "update soon"
            categories = []
            linkManga_base = link.a['href']
            rManga_base = session.get(linkManga_base)
            soupManga_base = BeautifulSoup(rManga_base.content, 'html.parser')
            print("\nlink manga: ",linkManga_base)

            # MANGA NAME
            manga_name = soupManga_base.find('h1', class_='name bigger').text

            # THUMBNAIL MANGA
            thumbnail = soupManga_base.find('div', 'thumb text-center').img['src']
            
            # RATING STAR, NUMBER OF RATING, NUMBER OF VIEWS
            rate = int(float(soupManga_base.find('div', class_ = 'rating-container').text.replace('\n',"").replace(" ","")))
            # print(rate, type(rate))
            rating_result = soupManga_base.find('div', class_ = 'rating-result').text
            n_of_views = soupManga_base.find('div', class_ = 'view-times').text.replace("\n", "")
            
            # AUTHORS MANGA
            author = ""
            authors = soupManga_base.find('div', 'author')
            for a in authors.find_all('a', title=True):
                name_author = a['title'] + ", "
                author += name_author
            author = author[:-2]

            # MySQL : INSERT TABLE 'authors'
            for author_name in author.replace(" ","").split(","):
                if author_name not in authors:
                    author_list.append(author_name)
                    author_id.append(cnt_author_id)
                    cnt_author_id += 1
                    mydb.insert_2_authors(name=author_name, created_at=current_time, updated_at=current_time)
                    mydb.data_commit()
            # MANGA DESCRIPTION
            desc = soupManga_base.find('div', {"id": "desc"}).text
            desc = desc.replace("[", "").replace("]", "").replace('"', "").replace("'","")
            
            # CATEGORIES
            cats = soupManga_base.find('div', class_="genre")
            manga_released_date="updating"
            for category in cats.find_all('a', href=True):
                categories.append(category.text)

            # LAST UPDATE
            try:
                last_update = soupManga_base.find('div', class_='chapter-date')['title']
                last_update = last_update.split(" ")[0]
            except Exception as e:
                print(f"\nNONE CHAPTER FROM : {linkManga_base}")

            # MySQL : INSERT TABLE : 'categories'
            slug=""
            title=""
            for i in categories:
                title = title + "\n" + i
                i = i.lower().replace(" ","-")
                slug = slug + "-" + i
            title = "Genre(s):" + title
            slug = "genres"+ slug
            mydb.insert_2_categories(domain_id=1, title=title, slug=slug, image=None,
            description=None, created_at=current_time, updated_at=current_time)
            mydb.data_commit()
            
            print("\nmanga_id:", manga_id)
            print("\nmanga_name:", manga_name)
            print("\nthumbnail:", thumbnail)
            print("\nauthor:", author)
            print("\ncategories:",categories)
            # print("\nDescription:", desc)
            print("\nlast_update:", last_update)

            # DUYỆT TỪNG PAGE TRUYỆN TRONG 1 MANGA
            last_page = 1
            cnt_page = 1
            try:
                last_page = int(soupManga_base.findAll('a', class_ = 'next page-numbers')[1].get('href').split("/")[4].split("-")[1])
            except Exception as e:
                print("\nTotal_page:", 1)
            else:
                print("\nTotal_page:", last_page)

            # RELEASE DATE
            YOOOO = linkManga_base + '/page-' + str(last_page)
            rYOOOOO = session.get(YOOOO)
            soupYOOOOO = BeautifulSoup(rYOOOOO.content, 'html.parser')
            try:
                manga_released_date = soupYOOOOO.findAll('div', class_ = 'chapter-date')[-1]['title']
                print("\nReleased at:", manga_released_date)
            except:
                print("\nReleased at:", manga_released_date)
            # LẤY URL TỪNG CHAPTER
            while last_page>=cnt_page:
                # LẤY LINK MANGA
                linkManga = linkManga_base + '/page-' + str(last_page)
                print("\npage {}:".format(last_page), linkManga)

                # LẤY DATA TỪ MANGA
                rManga = session.get(linkManga)
                soupManga = BeautifulSoup(rManga.content, 'html.parser')
                last_page -= 1

                # LẤY TÊN CÁC CHAPTER TRONG PAGE
                for chaptername in soupManga.findAll('h2', class_="chap")[::-1]:
                    chaptername = chaptername.text.replace("  ", "-").lower()
                    chapter_list.append((chaptername[:-1].replace(".","-"), chapterid))
                    chapterid += 1
                # print(chapter_list)

            if len(chapter_list) > 0:
                for i in range(len(chapter_list)):
                    # chapter_id, chapter_name, page_list
                    chapter_id = chapter_list[i][1]
                    chaptername = None
                    chapter_name = None
                    chapter = dict()
                    page_list = []

                    # LẤY DATA TỪNG CHAPTER
                    linkChapter = linkManga_base + '-' + chapter_list[i][0] + '/'
                    # print("Link chapter : \n\n", linkChapter)
                    rChapter = session.get(linkChapter)
                    soupChapter = BeautifulSoup(rChapter.content, 'html.parser')

                    # TÊN CHAPTER
                    try:
                        chapter_name = soupChapter.find('a', class_ = 'bg-tt').text
                        chaptername = chapter_name + ' - BeeToon.net'
                        print("\nChapter Name: ", chaptername)
                    except Exception as e:
                        print("\nNo Chapter Name")

                    # CRAWL ẢNH TỪNG CHAPTER
                    for img in soupChapter.findAll('img', attrs={'alt': chaptername}):
                        src = img['src'].replace('\n', '')
                        page_list.append(src)
                    
                    # print(page_list)
                    # THÊM KEY Chapters vào DATA CHÍNH
                    chapter['chapter_id'] = chapter_id
                    chapter['chapter_name'] = chapter_name
                    chapter['page_list'] = page_list
                    chapters.append(chapter)
                    # print("\nchapters: ", chapters)

                    # MySQL : INSERT TABLE 'chapters'
                    mydb.insert_2_chapters(manga_id=manga_id, name=chapter['chapter_name'],
                    thumbnail_count=len(chapter['page_list']),
                    created_at=current_time, updated_at=current_time)
                    mydb.data_commit()

                    # MySQL : INSERT TABLE 'chapter_thumbnails'
                    for chapter_thumbnail_url in chapter['page_list']:
                        mydb.insert_2_chapter_thumbnails(chapter_id=chapter['chapter_id'], 
                        thumbnail_url=chapter_thumbnail_url,
                        created_at= current_time, updated_at=current_time)  
                        mydb.data_commit()
                # print("\nchapters:", chapters)
            data_crawl['manga_id'] = manga_id
            data_crawl['manga_name'] = manga_name
            data_crawl['thumbnail'] = thumbnail
            data_crawl['author'] = author
            data_crawl['last-update'] = last_update
            data_crawl['categories'] = categories
            data_crawl['chapters'] = chapters
            
            # MySQL : INSERT TABLE 'manga'
            manga_title = data_crawl['manga_name']
            manga_slug = remove_non_letters(manga_title).lower().replace(" ","-")
            manga_image = data_crawl['thumbnail']
            manga_chapter_count = int(len(data_crawl['chapters']))
            mydb.insert_2_manga(domain_id=1, title=manga_name, slug=manga_slug, 
            image=thumbnail, chapter_count=manga_chapter_count,rank=rate, description=desc, release_at=manga_released_date,
            created_at=current_time, updated_at=current_time)
            # print(mydb.insert_query)
            mydb.data_commit()
            
            # MySQL : INSERT TABLE 'manga_authors'
            manga_authors_author_id = []
            for author_name in author.replace(" ","").split(","):
                manga_authors_author_id.append(author_list.index(author_name))
            mydb.insert_2_manga_authors(manga_id=manga_id, author_id=list_2_int(manga_authors_author_id))
            mydb.data_commit()

            # MySQL : INSERT TABLE 'manga_categories'
            for category in categories:
                if category not in cate_list:
                    cate_list.append(category)
            for i in range(len(cate_list)):
                mydb.insert_2_manga_categories(category_id=i+1, manga_id=i+1)
                mydb.data_commit()

            beetoon_crawl.append(data_crawl)
            print("---"*20)
        # print(comics)
        cnt+=1

crawl_beetoon_data('latest-update', 1, 100)

with open('data1.json', 'w', encoding="utf-8") as f:
    json.dump(beetoon_crawl, f, indent=4)