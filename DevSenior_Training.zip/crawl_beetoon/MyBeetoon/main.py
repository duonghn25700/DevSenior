from flask import Flask, jsonify, request
from flask_restful import Api, Resource
from utils.utils import beetoon_api
import requests
import json

mydb = beetoon_api()
app = Flask(__name__)


# Danh sach tat ca category
@app.route("/manga/categories", methods=["GET"])
def get_categories():
    order_by = request.args.get('order_by', 'id')
    sort_direction = request.args.get('sort_direction', 'asc')
    search_text = request.args.get('search_text', '')
    data = mydb.get_categories()
    return jsonify(data)

# Danh sach manga theo category id
@app.route("/manga/categories/<int:category_id>")
def get_category_by_id(category_id):
    data = mydb.get_category_by_id(category_id)

    return jsonify(data)
# Danh sach tat ca manga
@app.route("/manga", methods=["GET"])
def get_manga():
    data = mydb.get_from_manga()
    comics = data["data"]

    per_page = request.args.get('page_size', 50, type=int)
    page = request.args.get('page', 1, type=int)
    
    start_index = (page - 1) * per_page
    end_index = start_index + per_page
    sliced_comics = comics[start_index:end_index]
    data['data'] = sliced_comics

    return jsonify(data)

# Chi tiet manga theo ID
@app.route("/manga/<int:manga_id>", methods = ['GET'])
def get_manga_by_id(manga_id):
    data = mydb.get_manga_by_id(manga_id)
    return jsonify(data)

# Danh sach chapter theo manga id
@app.route("/manga/<int:manga_id>/chapter", methods = ['GET'])
def get_chapter_list_by_manga(manga_id):
    data = mydb.get_chapter_list_by_manga(manga_id)
    return jsonify(data)

# Chi tiet chapter theo id
@app.route("/manga/<int:manga_id>/chapter/chapter-<int:chapter_id>", methods = ['GET'])
def get_chapter_by_id(manga_id, chapter_id):
    data = mydb.get_chapter_by_id(manga_id, chapter_id)
    return jsonify(data)

# User register
@app.route("/register", methods=["POST"])
def user_register():
    username = request.form.get('username')
    email = request.form.get('email')
    password = request.form.get('password')
    data = mydb.insert_user_inf(username,email, password)
    return jsonify({"Message": data})

# User login
@app.route("/login", methods=["POST"])
def user_login():
    username = request.form.get('username')
    email = request.form.get('email')
    password = request.form.get('password')

    message = mydb.check_user_login(username,email,password)
    return jsonify({"Message":message})

# Send veirify account
@app.route("/send-verify", methods=["POST"])
def verify_email():
    email = request.form.get('email')
    message = mydb.verify_email(email)
    return jsonify({"Message":message})

# Comment theo manga
@app.route("/manga/<int:manga_id>/comments", methods=["GET", "POST"])
def post_comment_manga(manga_id):
    if request.method == "POST":
        comment = request.form.get('content')
        user_id = request.form.get('user_id', type=int)
        message = mydb.post_comment_manga(user_id,manga_id,comment)
        return jsonify({"Message":message})








@app.route("/", methods=["GET"])
def get_new():
    return jsonify({"data":"Welcome to Tozi's Manga"})

# api.add_resource({"data": "Hello World"}, "/hello")

if __name__ == "__main__":
    # print(mydb.get_from_manga()[0])
    app.run(debug=True)