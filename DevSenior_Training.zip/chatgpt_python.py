import pyautogui
import pytesseract
import time
import cv2
import mss
import numpy

# initialize
full_frame = {'top': 150, 'left': 680, 'width': 850, 'height': 700}
gen_frame = {'top': 845, 'left': 1015, 'width': 200, 'height': 50}
check_frame = {'top': 700, 'left': 680, 'width': 850, 'height': 70}
error_frame = {'top': 900, 'left': 900, 'width': 400, 'height': 50}

pytesseract.pytesseract.tesseract_cmd = 'C:/Program Files/Tesseract-OCR/tesseract.exe'

# COPY SELECTED TEXT
def copy_clipboard():
    pyautogui.hotkey('ctrl', 'c')
    time.sleep(.01)  # ctrl-c is usually very fast but your program may execute faster
    return pyperclip.paste()

# GET TEXT FROM SELECTED TO STRING TYPE
def get_text_from_position(start_x, start_y, end_x, end_y):
    pyautogui.click(start_x, start_y)
    pyautogui.mouseDown(start_x, start_y)
    pyautogui.drag(end_x - start_x, end_y - start_y, duration=1)
    pyautogui.mouseUp(end_x, end_y)
    var = copy_clipboard()
    return var

# GET TEXT FROM AN IMAGE
def image_2_text(rec):
    img = numpy.asarray(sct.grab(rec))
    text_read = pytesseract.image_to_string(img).replace("|", "I")
    return text_read


# MAINLOOP
with mss.mss() as sct:
    while True:
        # NHẬP MESSAGE 
        usermsg = input()
        response = "There's something wrong. Try again!"
        if usermsg == "RESET ALL":
            pyautogui.click(900, 920)
            pyautogui.press("F5")
            print("\nWait a seconds...")
            time.sleep(10)

        # TEXT ĐỌC ĐƯỢC TRONG KHUNG HÌNH
        pyautogui.moveTo(900, 920)
        pyautogui.click(900, 920)
        pyautogui.typewrite(usermsg)
        pyautogui.typewrite(['ENTER'])
        pyautogui.click(1580, 920)

        time.sleep(7)
        gen_frame_text = "Stop generating"
        
        
        error_frame_text = image_2_text(error_frame)

        # KIỂM TRA OPENAI CÓ LỖI KO
        if "There was an error generating" in error_frame_text:
            print("An error occurred. Please send again or press 'RESET ALL'")

        # KHÔNG LỖI THÌ TRẢ KẾT QUẢ
        else:
            while gen_frame_text == "Stop generating":
                gen_frame_text = image_2_text(gen_frame)[2:-1]
            
            check_frame_text = image_2_text(check_frame)
            if check_frame_text != "":
                start_x, start_y, end_x, end_y = 1500, 760, 600, 760
                response = get_text_from_position(x, y)
            else:
                full_frame_text = image_2_text(full_frame)
                if usermsg in full_frame_text:
                    txt_id = full_frame_text.index(usermsg)
                    response = full_frame_text[txt_id + len(usermsg):]
                else:
                    response = full_frame_text.replace(usermsg, "")
            print("\nYour answer: ",response)