import mysql.connector
from beetoon.beetoon2sql_v2 import beetoon_insert

mydb = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="crawl_beetoon"
)

mycursor = mydb.cursor()


# select_query = """SELECT * FROM chapter_thumbnails WHERE last_update=02/07/2023"""
# mycursor.execute(select_query)
# record = mycursor.fetchall()
# print(record)

for chapter_id in range(1,100):
    delete_query =f"""DELETE FROM `manga_categories` WHERE `manga_categories`.`manga_id` = {chapter_id}"""
    mycursor.execute(delete_query)
mydb.commit()