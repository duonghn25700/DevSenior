from bs4 import BeautifulSoup
from urllib.parse import urlparse
import requests
import json
import mysql.connector
from beetoon.beetoon2sql import beetoon_insert

mydb = beetoon_insert(db='crawl_beetoon')


# mydb.insert_2_authors(name= "123",created_at=1, updated_at=1)
# mydb.insert_2_categories(domain_id=12, title='ava', slug='acac', image='asx', description='desc', created_at=123, updated_at=123)
# mydb.insert_2_chapters(manga_id=12, name="abc", created_at=123, updated_at=123)
# mydb.insert_2_chapter_thumbnails(chapter_id=12, thumbnail_url="123", created_at=1, updated_at=1)
# mydb.insert_2_domain_crawlers(domain_name="123", display_name="123", description="1", created_at=12, updated_at=12)
# mydb.insert_2_manga(domain_id=12, title="abc", slug='12', image='12', description='1', release_at="123", updated_at=123)
# mydb.insert_2_manga_authors(manga_id=,author_id=)
# mydb.insert_2_manga_categories(category_id=12, manga_id=12)