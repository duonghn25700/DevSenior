'''
CoinSnap
'''
import os
import torch
import torch.nn as nn
import torchvision
from torchvision import models, datasets, transforms
from PIL import Image
import json
import numpy as np
import ast
import matplotlib.pyplot as plt
from src.utils.inference import Predictor, BaseTranform
from configparser import ConfigParser
from flask import Flask, jsonify, request, render_template
from flask_restful import Api, Resource
from coinnet_app.coinsql import CoinDatabase



# @load config
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
config = ConfigParser()
config.read("config.ini")

# @config coin database
coinConfig = {
    'user'    : ast.literal_eval(config["DATABASE"]['user']),
    'password': ast.literal_eval(config["DATABASE"]['password']),
    'host'    : ast.literal_eval(config["DATABASE"]['host']),
    'db'      : ast.literal_eval(config["DATABASE"]['database']),
}
mydb = CoinDatabase(**coinConfig)

# Classifers
num_class = int(config["DEFAULT"]['classes'])
class_names = ast.literal_eval(config['INFERENCE']['class_names'])
class_index = []

# Cat to name
cat_to_name = ast.literal_eval(config['INFERENCE']['cat_to_name'])
with open(cat_to_name, 'r') as f:
    data = json.load(f)
for name in class_names:
    class_index.append(data[name])

# Load back side model
b_model = models.resnet50(pretrained=True)
b_model = b_model.to(device)
num_ftrs = b_model.fc.in_features
b_model.fc = nn.Linear(num_ftrs, num_class)

# Load front side model
f_model = models.resnet50(pretrained=True)
f_model = f_model.to(device)
num_ftrs = f_model.fc.in_features
f_model.fc = nn.Linear(num_ftrs, num_class)

# Load checkpoint
back_path = ast.literal_eval(config["CHECKPOINT"]['b_checkpoint'])
front_path = ast.literal_eval(config["CHECKPOINT"]['f_checkpoint'])
b_checkpoint = torch.load(back_path, map_location=torch.device('cpu'))['model_state_dict']
f_checkpoint = torch.load(front_path, map_location=torch.device('cpu'))['model_state_dict']
b_model.load_state_dict(b_checkpoint)
b_model.eval()
f_model.load_state_dict(f_checkpoint)
f_model.eval()


# Prediction
predictor = Predictor(class_index)

# Transform parameters
resize = ast.literal_eval(config['PARAMETERS']['resize'])
mean = ast.literal_eval(config['PARAMETERS']['mean'])
std = ast.literal_eval(config['PARAMETERS']['std'])
transform = BaseTranform(resize, mean, std)

def coindetect(img, model):
    # img = Image.open(img)
    img_transformed = transform(img)
    img_transformed = img_transformed.unsqueeze_(0)
    out = model(img_transformed)
    result, score = predictor.predict_max(out)
    return result, np.max(score)

def coinSnap(b_img, f_img):
    b_predict_1, b_score1 = coindetect(b_img, b_model)
    b_predict_2, b_score2 = coindetect(f_img, b_model)
    b_result, f_result = None, None
    b_score, f_score = None, None

    if b_score1>b_score2:
        b_result = b_predict_1
        b_score = b_score1

        f_result, f_score = coindetect(f_img, f_model)
    elif b_score1<b_score2:
        b_result = b_predict_2
        b_score = b_score2

        f_result, f_score = coindetect(b_img, f_model)

    if b_score>f_score:
        return b_result
    elif b_score<f_score:
        return b_result

def get_1_value_by_column(val_find, col_find, table_name):
    select_query = f"SELECT * FROM `{table_name}` WHERE `{col_find}`='{val_find}'"
    mydb.mycursor.execute(select_query)
    tmp = mydb.mycursor.fetchall()[0]
    return tmp

def get_coin_id_by_name(col_find, val_find, table_name ='coin'):
    select_query = f"SELECT `id` from `coin` WHERE `{col_find}` = '{val_find}'"
    mydb.mycursor.execute(select_query)
    tmp = mydb.mycursor.fetchall()[0]
    return tmp[0]

def get_coin_snap(b_img, f_img):
    coin_1 = coinSnap(b_img, f_img)
    data = dict()
    for i in range(3):
        coin_data = dict()
        coin_data['id'] = get_coin_id_by_name(col_find='name', val_find=coin_1[i]) 
        coin_data['name'] = coin_1[i]
        data[f'Top {i+1}:'] = coin_data
    return data

def get_coin_id_info(coin_id):
    try:
        select_query = f"SELECT * FROM `coin` WHERE `id`='{coin_id}'"
        mydb.mycursor.execute(select_query)
        tmp = mydb.mycursor.fetchall()[0]
        coin_data = dict()
        coin_data['name'] = tmp[1]
        coin_data['description'] = tmp[2]
        coin_data['Years'] = tmp[3]
        coin_data['Design date'] = tmp[4]
        coin_data['Value'] = tmp[5]
        coin_data['Weight'] = tmp[6]
        coin_data['Diameter'] = tmp[7]
        coin_data['Thickness'] = tmp[8]
        coin_data['Shape'] = tmp[9]
        coin_data['Technique'] = tmp[10]
        coin_data['created_at'] = tmp[11]
        coin_data['updated_at'] = tmp[12]
        return coin_data
    except Exception as err:
        # log debugger
        log_error(f"{err}")
        # If a database error occurs, print the error message and attempt to reconnect
        self.mydatabase, self.mycursor = self.db_connection()
        self.mycursor.close()
        self.mydatabase.close()
        return jsonify({"Message": f"Error: {err}, refresh to reconnect"})