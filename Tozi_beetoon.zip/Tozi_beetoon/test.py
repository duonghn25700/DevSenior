import mysql.connector
from beetoon.beetoon2sql_v4 import beetoon_insert
from datetime import datetime
host='localhost'
user='root'
password="" 
db='crawl_beetoon'
mydb = beetoon_insert(
            host=host,
            user=user,
            password=password,
            db=db
        )
cate_list = ["Romance","School Life"]
categories = []
for category in cate_list:
    cate_dict = dict()
    cate_id = mydb.get_1_value_by_column(col_find='title', val=category, col_get='category_id', table_name='categories')
    # cate_dict['id'] = cate_id
    # cate_dict['title'] = category
    # cate_dict['is_active'] = True
    # cate_dict['description'] = None
    # categories.append(cate_dict)
    print(cate_id)
# print(categories)
