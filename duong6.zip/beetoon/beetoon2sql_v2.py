import requests
import json
import mysql.connector

class beetoon_insert:
    def __init__(self,host='localhost',user='root',password="", db='crawl_beetoon'):
        self.mydatabase = mysql.connector.connect(
            host=host,
            user=user,
            password=password,
            database=db
        )
        self.mycursor = self.mydatabase.cursor()
        self.insert_query = None

    def insert_2_authors(self, name, created_at, updated_at, deleted_at=None, table_name='authors'):
        '''
        `id` bigint UNSIGNED NOT NULL,
        `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
        `created_at` int NOT NULL,
        `updated_at` int NOT NULL,
        `deleted_at` int DEFAULT NULL
        Example:
        (1, 'Sengae', 1675607871, 1675607871, NULL),
        (2, 'Fukui Takumi', 1675607874, 1675607874, NULL)
        '''
        self.insert_query = f"""INSERT INTO `{table_name}`(`name`, `created_at`, `updated_at`) VALUES ("{name}","{created_at}","{updated_at}")"""
        # self.mycursor.execute(insert_query)
        # self.mydatabase.commit()

    def insert_2_categories(self, domain_id,title,slug,image,description,created_at,updated_at,deleted_at=None,table_name='categories'):
        '''
        `id` bigint UNSIGNED NOT NULL,
        `domain_id` bigint UNSIGNED NOT NULL,
        `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
        `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
        `is_active` tinyint NOT NULL DEFAULT '1',
        `total_manga` int DEFAULT '0',
        `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
        `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
        `created_at` int NOT NULL,
        `updated_at` int NOT NULL,
        `deleted_at` int DEFAULT NULL

        example:
        (1, 1, 'Genre(s):\n4-Koma\nComedy\nSlice Of Life\nWebtoon\n', 'genres-4-koma-comedy-slice-of-life-webtoon', 1, 0, 
        NULL, NULL, 1675607871, 1675607871, NULL),
        (2, 1, 'Genre(s):\nAction\nShounen\nSupernatural\n', 'genres-action-shounen-supernatural', 1, 0, 
        NULL, NULL, 1675607874, 1675607874, NULL),
        '''

        self.insert_query = f"""INSERT INTO `{table_name}`(`domain_id`,`title`,`slug`,`image`,`description`,`created_at`,`updated_at`) VALUES ("{domain_id}","{title}","{slug}","{image}","{description}","{created_at}","{updated_at}")"""
        # self.mycursor.execute(insert_query)
        # self.mydatabase.commit()
    
    def insert_2_chapters(self,manga_id,name,thumbnail_count,created_at,updated_at,deleted_at=None,table_name='chapters'):

        '''
        `id` bigint UNSIGNED NOT NULL,
        `manga_id` bigint UNSIGNED NOT NULL,
        `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
        `is_active` tinyint NOT NULL DEFAULT '1',
        `thumbnail_count` int DEFAULT '0',
        `created_at` int NOT NULL,
        `updated_at` int NOT NULL,
        `deleted_at` int DEFAULT NULL

        Example:
        (1, 1, 'At Each Other\'s Throats Ch.176', 1, 1, 1675607871, 1675607871, NULL),
        (2, 1, 'At Each Other\'s Throats Ch.175', 1, 1, 1675607871, 1675607871, NULL),
        '''
        self.insert_query = f"""INSERT INTO `{table_name}`(`manga_id`,`name`,`thumbnail_count`,`created_at`,`updated_at`) VALUES ("{manga_id}","{name}","{thumbnail_count}","{created_at}","{updated_at}")"""
        # self.mycursor.execute(insert_query)
        # self.mydatabase.commit()

    def insert_2_chapter_thumbnails(self, chapter_id, thumbnail_url,created_at,updated_at,deleted_at=None,table_name='chapter_thumbnails'):
        
        '''
        
        `id` bigint UNSIGNED NOT NULL,
        `chapter_id` bigint UNSIGNED NOT NULL,
        `thumbnail_url` text COLLATE utf8mb4_unicode_ci NOT NULL,
        `is_active` tinyint NOT NULL DEFAULT '1',
        `created_at` int NOT NULL,
        `updated_at` int NOT NULL,
        `deleted_at` int DEFAULT NULL
        
        Example:
        (1, 1, 'https://pic9.yx247.com/comics/pic9/50/45170/881693/335656f07e73e44e19221e6649796c54.jpg', 1, 1675607871, 1675607871, NULL),
        (2, 2, 'https://pic9.yx247.com/comics/pic9/50/45170/881692/e79cbf3b27c582d5f0c51e81a2b82562.jpg', 1, 1675607871, 1675607871, NULL),
        '''
        self.insert_query = f"""INSERT INTO `{table_name}`(`chapter_id`, `thumbnail_url`,`created_at`,`updated_at`) VALUES ("{chapter_id}","{thumbnail_url}","{created_at}","{updated_at}")"""
        # self.mycursor.execute(insert_query)
        # self.mydatabase.commit()

    def insert_2_domain_crawlers(self,domain_name,display_name,description,created_at,updated_at,deleted_at=None,table_name='domain_crawlers'):
        '''
        `id` bigint UNSIGNED NOT NULL,
        `domain_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
        `display_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
        `is_active` tinyint NOT NULL DEFAULT '1',
        `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
        `created_at` int NOT NULL,
        `updated_at` int NOT NULL,
        `deleted_at` int DEFAULT NULL

        Example:
        (1, 'www.ninemanga.com', 'ninemanga.com', 1, 'www.ninemanga.com', 1675607871, 1675607871, NULL)
        '''
        self.insert_query = f"""INSERT INTO `{table_name}`(`domain_name`,`display_name`,`description`,`created_at`,`deleted_at`) VALUES ("{domain_name}","{display_name}","{description}","{created_at}", "{updated_at}")"""
        # self.mycursor.execute(insert_query)
        # self.mydatabase.commit()
    
    def insert_2_manga(self,domain_id,title,slug,image,chapter_count,rank,description,release_at,created_at,updated_at,deleted_at=None,table_name='manga'):

        '''
        `id` bigint UNSIGNED NOT NULL,
        `domain_id` bigint UNSIGNED NOT NULL,
        `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'manga',
        `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
        `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
        `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
        `is_active` tinyint NOT NULL DEFAULT '1',
        `image` text COLLATE utf8mb4_unicode_ci,
        `chapter_count` int DEFAULT '0',
        `rank` int DEFAULT '5',
        `description` text COLLATE utf8mb4_unicode_ci,
        `release_at` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
        `created_at` int NOT NULL,
        `updated_at` int NOT NULL,
        `deleted_at` int DEFAULT NULL
        '''
        self.insert_query = f"""INSERT INTO `{table_name}`(`domain_id`,`title`,`slug`,`image`,`chapter_count`,`rank`,`description`,`release_at`,`updated_at`,`created_at`) VALUES ("{domain_id}","{title}","{slug}","{image}","{chapter_count}" ,"{rank}", "{description}", "{release_at}","{updated_at}", "{created_at}")"""
        # self.mycursor.execute(insert_query)
        # self.mydatabase.commit()
    
    def insert_2_manga_authors(self,manga_id=int,author_id=int,table_name='manga_authors'):
        '''
        `manga_id` bigint UNSIGNED NOT NULL,
        `author_id` bigint UNSIGNED NOT NULL
        
        Example:
        (1, 1),
        (2, 2)
        '''
        self.insert_query = f"""INSERT INTO `{table_name}`(`manga_id`,`author_id`) VALUES ("{manga_id}","{author_id}")"""
        # self.mycursor.execute(insert_query)
        # self.mydatabase.commit()

    def insert_2_manga_categories(self,category_id,manga_id, table_name='manga_categories'):
        '''
        `category_id` bigint UNSIGNED NOT NULL,
        `manga_id` bigint UNSIGNED NOT NULL

        Example:
        (1, 1),
        (2, 2),
        '''
        self.insert_query = f"""INSERT INTO `{table_name}`(`category_id`,`manga_id`) VALUES ("{category_id}","{manga_id}")"""
        # self.mycursor.execute(insert_query)
        # self.mydatabase.commit()

    def insert_2_categories_name(self,category_id,category_name,table_name='categories_name'):
        '''
        `category_id` bigint UNSIGNED NOT NULL,
        `category_name` bigint UNSIGNED NOT NULL
        
        example:
        (1, "MANHWA")
        (2, "ACTION")
        '''
        self.insert_query = f"""INSERT INTO `{table_name}`(`category_id`,`category_name`) VALUES ("{category_id}","{category_name}")"""
        # self.mycursor.execute(insert_query)
        # self.mydatabase.commit()
    
    def insert_2_author_name(self, author_id, author_name, table_name='author_name'):
        self.insert_query = f"""INSERT INTO {table_name} (author_id,author_name) VALUES ("{author_id}","{author_name}")"""

    def data_commit(self):
        self.mycursor.execute(self.insert_query)
        self.mydatabase.commit()