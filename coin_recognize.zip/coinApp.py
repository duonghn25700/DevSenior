'''
CoinSnap
'''
import os
import torch
import torch.nn as nn
import torchvision
from torchvision import models, datasets, transforms
from PIL import Image
import json
import numpy as np
import ast
import matplotlib.pyplot as plt
from datetime import datetime
import pytz
from src.utils.inference import Predictor, BaseTranform
from configparser import ConfigParser
from flask import Flask, jsonify, request, render_template
from flask_restful import Api, Resource
from coinnet_app.coinsql import CoinDatabase
from coinNet import *

def tuple_2_list(tups):
    for i in range(len(tups)):
        tups[i] = list(tups[i])
        tups[i] = tups[i][0]
    return tups

tz = pytz.timezone("Asia/Ho_Chi_Minh")
def get_all_row_by_column(col_find, val, table_name):
    mydb.select_query = f"SELECT * FROM `{table_name}` WHERE `{col_find}`='{val}'"
    mydb.mycursor.execute(mydb.select_query)
    tmp = mydb.mycursor.fetchall()
    return tmp

def update_1_value_by_column(col_find, val_find, col_update, val_update,table_name):
    mydb.update_query = f"""UPDATE `{table_name}` SET `{col_update}`='{val_update}' WHERE `{col_find}` = '{val_find}'"""
    mydb.mycursor.execute(mydb.update_query)
    mydb.mydatabase.commit()

def get_1_value_by_column(val_find, col_find, table_name):
    select_query = f"SELECT * FROM `{table_name}` WHERE `{col_find}`='{val_find}'"
    mydb.mycursor.execute(select_query)
    tmp = mydb.mycursor.fetchall()[0]
    return tmp

def get_1_value_by_1_column(col_find, val, col_get, table_name):
    mydb.select_query = f"""SELECT `{col_get}` FROM `{table_name}` WHERE `{col_find}`='{val}'"""
    mydb.mycursor.execute(mydb.select_query)
    tmp = mydb.mycursor.fetchall()
    return tuple_2_list(tmp)[0]

def get_all_value_in_column(column, table_name):
    mydb.select_query = f"SELECT `{column}` FROM `{table_name}`"
    mydb.mycursor.execute(mydb.select_query)
    tmp = mydb.mycursor.fetchall()
    return tuple_2_list(tmp)

def get_coin_id_by_name(col_find, val_find, table_name ='coin'):
    try:
        mydb.db_connection()
        select_query = f"SELECT `id` from `coin` WHERE `{col_find}` = '{val_find}'"
        mydb.mycursor.execute(select_query)
        tmp = mydb.mycursor.fetchall()[0]
        return tmp[0]
    except Exception as err:
        mydb.mydatabase, mydb.mycursor = mydb.db_connection()
        mydb.mycursor.close()
        mydb.mydatabase.close()
        return jsonify({"Message": f"Error: {err}, refresh to reconnect"})

def get_coin_snap(b_img, f_img):
    coin_1 = coinSnap(b_img, f_img)
    data = dict()
    for i in range(3):
        coin_data = dict()
        coin_data['id'] = get_coin_id_by_name(col_find='name', val_find=coin_1[i]) 
        coin_data['name'] = coin_1[i]
        data[f'Top {i+1}:'] = coin_data
    return data

def get_coin_id_info(coin_id):
    try:
        mydb.db_connection()
        select_query = f"SELECT * FROM `coin` WHERE `id`='{coin_id}'"
        mydb.mycursor.execute(select_query)
        tmp = mydb.mycursor.fetchall()[0]
        coin_data = dict()
        coin_data['id'] = coin_id
        coin_data['name'] = tmp[1]
        coin_data['description'] = tmp[2]
        coin_data['Years'] = tmp[3]
        coin_data['Design date'] = tmp[4]
        coin_data['Value'] = tmp[5]
        coin_data['Weight'] = tmp[6]
        coin_data['Diameter'] = tmp[7]
        coin_data['Thickness'] = tmp[8]
        coin_data['Shape'] = tmp[9]
        coin_data['Technique'] = tmp[10]
        coin_data['created_at'] = tmp[11]
        coin_data['updated_at'] = tmp[12]
        return coin_data
    except Exception as err:
        # If a database error occurs, print the error message and attempt to reconnect
        mydb.mydatabase, mydb.mycursor = mydb.db_connection()
        mydb.mycursor.close()
        mydb.mydatabase.close()
        return jsonify({"Message": f"Error: {err}, refresh to reconnect"})

def insert_user_inf(username,email, password):
    try:
        data = dict()
        mydb.mydatabase, mydb.mycursor = mydb.db_connection()
        now = datetime.now(tz)
        current_time = now.strftime("%Y/%m/%d %H:%M:%S")
        if username == "":
            return "Please enter your username"
        elif email == "":
            return "Please enter your email"
        elif password == "":
            return "Please enter your password"
        # data['message'] = msg
        # return data
        user_check = f"""SELECT COUNT(*) FROM `user_information` WHERE `username`='{username}'"""
        email_check = f"""SELECT COUNT(*) FROM `user_information` WHERE `email`='{email}'"""

        mydb.mycursor.execute(user_check)
        user_count = mydb.mycursor.fetchone()[0]
        mydb.mycursor.execute(email_check)
        email_count = mydb.mycursor.fetchone()[0]
            
            # return {"message":email_count}
        if user_count>0:
            return "Username already existed, try again!"
        elif email_count>0:
            return "Email already existed, try again!"
        else:
            query = f"""INSERT INTO `user_information`(`username`,`email`, `password`,`created_at`,`updated_at`) VALUES ("{username}","{email}","{password}","{current_time}","{current_time}")"""
            mydb.mycursor.execute(query)
            mydb.mydatabase.commit()
            msg = f"""User : `{username}` registered successfully !"""
            data['message'] = msg
            return msg
    except Exception as err:
        # If a database error occurs, print the error message and attempt to reconnect
        mydb.mydatabase, mydb.mycursor = mydb.db_connection()
        mydb.mycursor.close()
        mydb.mydatabase.close()
        return f"Error: {err}, refresh to reconnect"

def check_user_login(username, email, password):
    try:
        table_name = 'user_information'
        mydb.mydatabase, mydb.mycursor = mydb.db_connection()
        if username != "":
            user_inf = get_all_row_by_column(col_find="username", val=username, table_name=table_name)
        elif email != "":
            user_inf = get_all_row_by_column(col_find="email", val=email, table_name=table_name)
        for user in user_inf:
            sql_username, sql_email, sql_password = user[1], user[2], user[3]
            if username == sql_username and password == sql_password or email == sql_email and password == sql_password:
                update_1_value_by_column(col_find="username", val_find=username, 
                col_update="is_active", val_update=1, table_name="user_information")
                return f"Login successfully !"
                break
        return f"Wrong username or password. Try again !"
    except Exception as err:
        # If a database error occurs, print the error message and attempt to reconnect
        mydb.mydatabase, mydb.mycursor = mydb.db_connection()
        mydb.mycursor.close()
        mydb.mydatabase.close()
        return f"Error: {err}, refresh to reconnect"

def check_user_logout(username):
    try:
        mydb.mydatabase, mydb.mycursor = mydb.db_connection()
        now = datetime.now(tz)
        current_time = now.strftime("%Y/%m/%d %H:%M:%S")
        # log_error("Success")
        try:
            user_state = get_1_value_by_1_column(col_find="username", val=username, col_get='is_active', table_name='user_information')
        except Exception:
            return f"Please log in first!"
        if user_state == 1:
            update_1_value_by_column(col_find="username", val_find=username, 
            col_update="is_active", val_update=0, table_name="user_information")
            update_1_value_by_column(col_find="username", val_find=username, 
            col_update="last_login", val_update=current_time, table_name="user_information")
            
            return f"Logged out successfully!"
        else:
            return f"Please log in first!"

    except Exception as err:
        # If a database error occurs, print the error message and attempt to reconnect
        mydb.mydatabase, mydb.mycursor = mydb.db_connection()
        mydb.mycursor.close()
        mydb.mydatabase.close()
        return f"Error: {err}, refresh to reconnect"

def user_change_password(username, old_password, new_password):
    try:
        mydb.mydatabase, mydb.mycursor = mydb.db_connection()
        try:
            user_data = get_all_row_by_column(col_find="username", val=username, table_name="user_information")[0]
        except Exception:
            return {"Message":"This username doesn't exist!"}
        
        user_password = user_data[3]
        if user_password != old_password:
            return {"Message":"Your old password is wrong"}
        else:
            if old_password == new_password:
                return {"Message":"Your new password must be different"}
            else:
                update_1_value_by_column(col_find="username", val_find=username, col_update="password", val_update=new_password, table_name="user_information")
                return {"Message":"Your password changed successfully!"}

    except Exception as err:
        # If a database error occurs, print the error message and attempt to reconnect
        mydb.mydatabase, mydb.mycursor = mydb.db_connection()
        mydb.mycursor.close()
        mydb.mydatabase.close()
        return f"Error: {err}, refresh to reconnect"

def user_add_favortite_coin(username, is_favorite, coin_id):
    try:
        mydb.mydatabase, mydb.mycursor = mydb.db_connection()
        now = datetime.now(tz)
        current_time = now.strftime("%Y/%m/%d %H:%M:%S")
        user_state = get_1_value_by_1_column(col_find="username", val=username, col_get='is_active', table_name='user_information')
        coin_id_list = get_all_value_in_column(column="id", table_name="coin")

        if user_state == 0:
            return f"Please log in to add your favorite manga"
        elif user_state == 1:
            try:
                mydb.select_query = f"""SELECT `collection` FROM `user_information` WHERE `username`='{username}'"""
                mydb.mycursor.execute(mydb.select_query)
                user_favorite_coin = tuple_2_list(mydb.mycursor.fetchall())
            except TypeError:
                user_favorite_coin = []
            favorite_coin = ""
            
            if coin_id not in coin_id_list:
                return f"This coin is not existed!"
            else:
                if user_favorite_coin[0] == None:
                    favorite_coin = str(coin_id)
                else:
                    if str(coin_id) in user_favorite_coin[0].split(","):
                        return f"This coin have already on your favorite"
                    else:
                        favorite_coin = user_favorite_coin[0]
                        favorite_coin += ',' + str(coin_id)

                update_1_value_by_column(col_find="username", val_find=username, col_update="collection", val_update=favorite_coin, table_name="user_information")
                update_1_value_by_column(col_find="username", val_find=username, col_update="updated_at", val_update=current_time, table_name="user_information")
                return f"This coin has added to your favorite"
    except Exception as err:
        # If a database error occurs, print the error message and attempt to reconnect
        mydb.mydatabase, mydb.mycursor = mydb.db_connection()
        mydb.mycursor.close()
        mydb.mydatabase.close()
        return f"Error: {err}, refresh to reconnect"

def user_remove_favorite_coin(username, is_favorite, coin_id):
    mydb.mydatabase, mydb.mycursor = mydb.db_connection()
    now = datetime.now(tz)
    current_time = now.strftime("%Y/%m/%d %H:%M:%S")
    user_state = get_1_value_by_1_column(col_find="username", val=username, col_get='is_active', table_name='user_information')
    if user_state == 0:
        return f"Please log in to remove your collection coin"
    elif user_state == 1:
        try:
            mydb.select_query = f"""SELECT `collection` FROM `user_information` WHERE `username`='{username}'"""
            mydb.mycursor.execute(mydb.select_query)
            user_favorite_coin = tuple_2_list(mydb.mycursor.fetchall())
        except TypeError:
            user_favorite_coin = ""
        
        if user_favorite_coin[0] == None:
            return f"You don't have any coin collection"
        else:
            user_favorite_coin[0] = user_favorite_coin[0].split(",")
            coin_id = str(coin_id)
            if coin_id not in user_favorite_coin[0]:
                return f'''You haven't add this coin to your favorite'''
            else:
                user_favorite_coin[0].pop(user_favorite_coin[0].index(coin_id))
                favorite_coin = ",".join(user_favorite_coin[0])
                update_1_value_by_column(col_find="username", val_find=username, col_update="collection", val_update=favorite_coin, table_name="user_information")
                update_1_value_by_column(col_find="username", val_find=username, col_update="updated_at", val_update=current_time, table_name="user_information")
                return f"This coin has removed from your collection"

def user_get_favorite_coin(username):
    try:
        mydb.mydatabase, mydb.mycursor = mydb.db_connection()
        try:
            mydb.select_query = f"""SELECT `collection` FROM `user_information` WHERE `username`='{username}'"""
            mydb.mycursor.execute(mydb.select_query)
            user_favorite_coin = tuple_2_list(mydb.mycursor.fetchall())
        except TypeError:
            user_favorite_coin = ""
        
        user_state = get_1_value_by_1_column(col_find="username", val=username, col_get='is_active', table_name='user_information')
        
        user_id = None
        alldata = dict()
        data_coin_list = list()
        
        if user_state == 0:
            user_id = get_1_value_by_1_column(col_find="username", val=username, col_get="id", table_name="user_information")
            return f"Please log in to see your favorite"
        else:
            if user_favorite_coin[0] == None:
                return f"No favorite coin"
            else:
                user_favorite_coin[0] = user_favorite_coin[0].split(",")
                for coin_id in user_favorite_coin[0]:
                    if coin_id != "":
                        coin_id = int(coin_id)
                        data_coin_list.append(get_coin_id_info(coin_id))
            alldata["data"] = data_coin_list
            return alldata
    except Exception as err:
        # If a database error occurs, print the error message and attempt to reconnect
        mydb.mydatabase, mydb.mycursor = mydb.db_connection()
        mydb.mycursor.close()
        mydb.mydatabase.close()
        return f"Error: {err}, refresh to reconnect"