from bs4 import BeautifulSoup
from urllib.parse import urlparse
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry
import json
import mysql.connector
from datetime import datetime
import time
from beetoon.beetoon2sql_v4 import beetoon_insert
import re


session = requests.Session()
retry = Retry(total=5, backoff_factor=0.1, status_forcelist=[ 500, 502, 503, 504 ])
adapter = HTTPAdapter(max_retries=retry)
session.mount('http://', adapter)
session.mount('https://', adapter)

r = session.get('https://ww6.beetoon.net/marshal-is-jealous-everyday')
soup = BeautifulSoup(r.content, 'html.parser')

views = soup.find('div', class_="new-chap").text.split(":")
print(int(views[1]))